import React,{Component} from 'react'

class Notfound extends Component{
    render() {
        return (
            <h2 className = 'notFound'> Y'a Pas ! </h2>
        )
            
        
    }
}
export default Notfound