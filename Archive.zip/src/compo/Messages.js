import React from 'react'

const Messages = () => {
    return (
        <p className='user-message'> MESSAGES</p>
    )
}

export default Messages